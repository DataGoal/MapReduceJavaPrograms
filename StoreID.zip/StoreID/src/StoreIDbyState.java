
import java.io.IOException;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;



//storeID,ItemID,QtySold,Price/qty,state
//11,101,20,10,MAH ---> output type
//to find the total qty sold by each store by each state

public class StoreIDbyState
{
	public static class MyMapper extends Mapper <LongWritable, Text, Text, Text>
	{
		private Text itemID = new Text();
		private Text entireRow = new Text();
		protected void map (LongWritable key, Text value, Context con) throws IOException, InterruptedException 
		{
				String[] str = value.toString().split(",");
				itemID.set(str[1]);
				entireRow.set(str[2]+","+str[4]);
				con.write(itemID,entireRow);
		}
	}
	public static class MyReducer extends Reducer <Text,Text,Text,IntWritable>
	{
		private Text OutputKey = new Text();
		private IntWritable result = new IntWritable();
		
		public void reduce (Text key, Iterable<Text> value, Context con) throws IOException, InterruptedException
		{
			int sum = 0;
			for (Text val:value)
			{
				OutputKey.set(key);
				String[] str = val.toString().split(",");
				sum += Integer.parseInt(str[0]);
			}
			result.set(sum);
			con.write(OutputKey, result);
		}
	}
	public static class partition extends Partitioner<Text,Text>
	{
		public int getPartition (Text key, Text value, int numReduceTasks)
		{
			String[] str = value.toString().split(",");
			if (str[1].equals("MAH"))
			{
				return 0;
			}
			else 
			{
				return 1;
			}
		}
	}
	 public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException 
	  {
	    Configuration conf = new Configuration();
		//conf.set("mapred.textoutputformat.separator", ",");
		Job job = Job.getInstance(conf);
	    job.setJarByClass(StoreIDbyState.class);
	    job.setJobName("Store");
	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);
	    job.setPartitionerClass(partition.class);
	    job.setNumReduceTasks(2);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(Text.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    
	    job.waitForCompletion(true);
	  }
}