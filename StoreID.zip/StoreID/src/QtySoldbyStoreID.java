
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;





//storeID,ItemID,QtySold,Price/qty,state
//11,101,20,10,MAH ---> output type
//to find qty sold for each item StoreID wise

public class QtySoldbyStoreID
{
	public static class MyMapper extends Mapper <LongWritable, Text, Text, IntWritable>
	{
		private Text ItemID = new Text();
		private IntWritable QtySold = new IntWritable();
		protected void map (LongWritable key, Text value, Context con) throws IOException, InterruptedException 
		{
				String[] str = value.toString().split(",");
				ItemID.set(str[1]);
				int qty = Integer.parseInt(str[2]);
				QtySold.set(qty);
				con.write(ItemID,QtySold);
		}
	}
	public static class MyReducer extends Reducer <Text,IntWritable,Text,IntWritable>
	{
		private Text OutputKey = new Text();
		private IntWritable result = new IntWritable();
		
		public void reduce (Text key, Iterable<IntWritable> value, Context con) throws IOException, InterruptedException
		{
			int sum = 0;
			for (IntWritable val:value)
			{
				OutputKey.set(key);
				sum += val.get();
			}
			result.set(sum);
			con.write(OutputKey, result);
		}
	}
	public static class partition extends Partitioner<Text,Text>
	{
		public int getPartition (Text key, Text value, int numReduceTasks)
		{
			String[] str = value.toString().split(",");
			if (str[1].equals("101"))
			{
				return 0;
			}
			else 
			{
				return 1;
			}
		}
	}
	
	 public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException 
	  {
	    Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		conf.set("mapred.textoutputformat.separator", ",");
	    job.setJarByClass(QtySoldbyStoreID.class);
	    job.setJobName("QtySoldbyStoreID");
	    job.setPartitionerClass(partition.class);
	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    
	    job.waitForCompletion(true);
	  }
}

