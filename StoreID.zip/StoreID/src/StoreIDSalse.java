
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;



//storeID,ItemID,QtySold,Price/qty,state
//11,101,20,10,MAH ---> output type
//to find the total qty sold by each store by each state

public class StoreIDSalse
{
	public static class MyMapper extends Mapper <LongWritable, Text, Text, IntWritable>
	{
		private Text storeID = new Text();
		private IntWritable total_price = new IntWritable();
		protected void map (LongWritable key, Text value, Context con) throws IOException, InterruptedException 
		{
				String[] str = value.toString().split(",");
				storeID.set(str[0]);
				int qty = Integer.parseInt(str[2]);
				int price = Integer.parseInt(str[3]);
				total_price.set(qty*price);
				con.write(storeID,total_price);
		}
	}
	public static class MyReducer extends Reducer <Text,IntWritable,Text,IntWritable>
	{
		private Text OutputKey = new Text();
		private IntWritable result = new IntWritable();
		
		public void reduce (Text key, Iterable<IntWritable> value, Context con) throws IOException, InterruptedException
		{
			int sum = 0;
			for (IntWritable val:value)
			{
				OutputKey.set(key);
				sum += val.get();
			}
			result.set(sum);
			con.write(OutputKey, result);
		}
	}
	
	 public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException 
	  {
	    Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		conf.set("mapred.textoutputformat.separator", ",");
	    job.setJarByClass(StoreIDSalse.class);
	    job.setJobName("StoreIDSalse");
	    job.setMapperClass(MyMapper.class);
	    job.setReducerClass(MyReducer.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    
	    job.waitForCompletion(true);
	  }
}
